from controller import Robot, Keyboard
import time

# Constants
TIME_STEP = 32
MAX_VELOCITY = 10.0
ANGLE_STEP = 40 * 3.14159 / 180  # 40 degrees in radians
POSITION_M = ANGLE_STEP          # +40 deg (擊出)
POSITION_K = 0.0                 # 0 deg  (收回)
KICK_DELAY = 0.5                 # 擊出後延遲時間 (秒)

# Initialize robot and keyboard
robot = Robot()
timestep = int(robot.getBasicTimeStep())
keyboard = Keyboard()
keyboard.enable(timestep)

# Get motor and sensor
try:
    motor = robot.getDevice('motor1')
    sensor = robot.getDevice('motor1_sensor')
    sensor.enable(timestep)
    mechanism_enabled = True
except Exception:
    mechanism_enabled = False

# Get wheels
try:
    wheels = [robot.getDevice(f"wheel{i+1}") for i in range(4)]
    for wheel in wheels:
        wheel.setPosition(float('inf'))  # Infinite position for velocity control
        wheel.setVelocity(0)
    platform_enabled = True
except Exception:
    platform_enabled = False

# Debounce key
key_pressed = {
    'k': False
}

while robot.step(timestep) != -1:
    key = keyboard.getKey()

    # Platform control
    if platform_enabled:
        if key == Keyboard.UP:
            for wheel in wheels:
                wheel.setVelocity(MAX_VELOCITY)
        elif key == Keyboard.DOWN:
            for wheel in wheels:
                wheel.setVelocity(-MAX_VELOCITY)
        elif key == Keyboard.LEFT:
            wheels[0].setVelocity(MAX_VELOCITY)
            wheels[1].setVelocity(-MAX_VELOCITY)
            wheels[2].setVelocity(MAX_VELOCITY)
            wheels[3].setVelocity(-MAX_VELOCITY)
        elif key == Keyboard.RIGHT:
            wheels[0].setVelocity(-MAX_VELOCITY)
            wheels[1].setVelocity(MAX_VELOCITY)
            wheels[2].setVelocity(-MAX_VELOCITY)
            wheels[3].setVelocity(MAX_VELOCITY)
        elif key == ord('Q') or key == ord('q'):
            print("Exiting...")
            break
        else:
            for wheel in wheels:
                wheel.setVelocity(0)

    # Kick mechanism control
    if mechanism_enabled:
        if key == ord('M') or key == ord('k'):
            if not key_pressed['M']:
                print("[KICK] 出擊 → 收回")
                motor.setPosition(POSITION_M)
                
                # 延遲（非阻塞式等待）
                start_time = robot.getTime()
                while robot.step(timestep) != -1:
                    if robot.getTime() - start_time >= KICK_DELAY:
                        break

                motor.setPosition(POSITION_K)
            key_pressed['M'] = True
        else:
            key_pressed['M'] = False
