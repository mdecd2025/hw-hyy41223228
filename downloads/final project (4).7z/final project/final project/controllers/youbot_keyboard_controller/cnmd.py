from controller import Robot, Keyboard
 
# 常數設定
TIME_STEP = 32  # 模擬步長 (ms)
MAX_VELOCITY = 10.0  # 馬達最大速度
ANGLE_STEP = 40 * 3.14159 / 180  # 40度轉弧度
POSITION_M = ANGLE_STEP  # 馬達目標位置 +40度
POSITION_K = 0.0         # 馬達目標位置 0度
 
# 初始化機器人、鍵盤
robot = Robot()
timestep = int(robot.getBasicTimeStep())
keyboard = Keyboard()
keyboard.enable(timestep)
 
# 嘗試初始化馬達與感測器
mechanism_enabled = False
motor = None
sensor = None
try:
    motor = robot.getDevice('motor1')
    sensor = robot.getDevice('motor1_sensor')
    sensor.enable(timestep)
    mechanism_enabled = True
except Exception as e:
    print(f"機構控制裝置初始化失敗: {e}")
 
# 嘗試初始化輪子馬達
platform_enabled = False
wheels = []
try:
    wheels = [robot.getDevice(f"wheel{i+1}") for i in range(4)]
    for wheel in wheels:
        wheel.setPosition(float('inf'))  # 無限位置啟動速度控制
        wheel.setVelocity(0)
    platform_enabled = True
except Exception as e:
    print(f"平台控制裝置初始化失敗: {e}")
 
# 狀態機，用來控制 M / K 的切換（避免重複觸發）
current_state = "allow_m"
 
# 防止長按重複觸發的旗標
key_pressed = {'m': False, 'k': False}
 
def stop_wheels():
    for w in wheels:
        w.setVelocity(0)
 
print("控制開始，使用方向鍵移動，M/K控制機構，Q退出")
 
while robot.step(timestep) != -1:
    key = keyboard.getKey()
 
    # 平台控制
    if platform_enabled:
        if key == Keyboard.UP:
            for w in wheels:
                w.setVelocity(MAX_VELOCITY)
        elif key == Keyboard.DOWN:
            for w in wheels:
                w.setVelocity(-MAX_VELOCITY)
        elif key == Keyboard.LEFT:
            # 左輪後退，右輪前進
            wheels[0].setVelocity(-MAX_VELOCITY)
            wheels[1].setVelocity(MAX_VELOCITY)
            wheels[2].setVelocity(-MAX_VELOCITY)
            wheels[3].setVelocity(MAX_VELOCITY)
        elif key == Keyboard.RIGHT:
            # 左輪前進，右輪後退
            wheels[0].setVelocity(MAX_VELOCITY)
            wheels[1].setVelocity(-MAX_VELOCITY)
            wheels[2].setVelocity(MAX_VELOCITY)
            wheels[3].setVelocity(-MAX_VELOCITY)
        elif key in (ord('Q'), ord('q')):
            print("Exiting...")
            break
        else:
            stop_wheels()
 
   