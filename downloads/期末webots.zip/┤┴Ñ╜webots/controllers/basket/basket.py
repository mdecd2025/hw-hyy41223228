from controller import Robot, Keyboard, Emitter

# Constants
WHEEL_RADIUS = 0.1  # Radius of the wheels in meters
L = 0.471  # Half of the robot's length
W = 0.376  # Half of the robot's width
MAX_VELOCITY = 10.0  # Maximum wheel velocity

# Initialize robot and keyboard
robot = Robot()
timestep = int(robot.getBasicTimeStep())
keyboard = Keyboard()
keyboard.enable(timestep)

# Get emitter device for sending score
emitter = robot.getDevice("score_emitter")

# Get distance sensor
sensor = robot.getDevice('sensor')
sensor.enable(timestep)
score = 0
last_score_time = 0
cooldown = 1.0

# Get motors
wheel5 = robot.getDevice("wheel5")  # Front-right
wheel6 = robot.getDevice("wheel6")  # Front-left
wheel7 = robot.getDevice("wheel7")  # Rear-right
wheel8 = robot.getDevice("wheel8")  # Rear-left

# Enable velocity control
for wheel in [wheel5, wheel6, wheel7, wheel8]:
    wheel.setPosition(float('inf'))
    wheel.setVelocity(0)

def set_wheel_velocity(v1, v2, v3, v4):
    wheel5.setVelocity(v1)
    wheel6.setVelocity(v2)
    wheel7.setVelocity(v3)
    wheel8.setVelocity(v4)

# Lookup table for AD to distance
lookup_table = [
    (1000, 0.00),
    (620, 0.12),
    (372, 0.13),
    (248, 0.14),
    (186, 0.15),
    (0, 0.18)
]

def ad_to_distance(ad_value):
    for i in range(len(lookup_table) - 1):
        a0, d0 = lookup_table[i]
        a1, d1 = lookup_table[i + 1]
        if a1 <= ad_value <= a0:
            return d0 + (d1 - d0) * (ad_value - a0) / (a1 - a0)
    if ad_value > lookup_table[0][0]:
        return lookup_table[0][1]
    return lookup_table[-1][1]

# User instructions
print("Controls:")
print("U = forward, J = backward, H = turn left, K = turn right, Q = quit")

# Main loop
keys = set()
while robot.step(timestep) != -1:
    key = keyboard.getKey()
    while key != -1:
        keys.add(key)
        key = keyboard.getKey()

    sensor_value = sensor.getValue()
    distance = ad_to_distance(sensor_value)
    current_time = robot.getTime()

    if ord('M') in keys or ord('m') in keys:
        print("Distance (M):", distance)
    if ord('K') in keys or ord('k') in keys:
        print("Distance (K):", distance)

    if distance < 0.19 and (current_time - last_score_time) > cooldown:
        score += 2
        last_score_time = current_time
        print("得分 +2")
        print("Current Distance:", distance)
        emitter.send(str(2))  # 送出得分

    # Movement control
    if ord('U') in keys or ord('u') in keys:
        set_wheel_velocity(MAX_VELOCITY, MAX_VELOCITY, MAX_VELOCITY, MAX_VELOCITY)
    elif ord('J') in keys or ord('j') in keys:
        set_wheel_velocity(-MAX_VELOCITY, -MAX_VELOCITY, -MAX_VELOCITY, -MAX_VELOCITY)
    elif ord('K') in keys or ord('k') in keys:
        set_wheel_velocity(-MAX_VELOCITY, MAX_VELOCITY, -MAX_VELOCITY, MAX_VELOCITY)
    elif ord('H') in keys or ord('h') in keys:
        set_wheel_velocity(MAX_VELOCITY, -MAX_VELOCITY, MAX_VELOCITY, -MAX_VELOCITY)
    elif ord('Q') in keys or ord('q') in keys:
        print("Exiting...")
        break
    else:
        set_wheel_velocity(0, 0, 0, 0)

    keys.clear()
